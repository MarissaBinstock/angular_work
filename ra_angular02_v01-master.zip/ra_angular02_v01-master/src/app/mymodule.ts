export function SayGoodbye(log: (s: string) => void) {
  log("Goodbye :(");
}