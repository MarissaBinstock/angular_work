import 'source-map-support/register'
import {SayGoodbye} from './mymodule'

console.log('Hello there, Red Academy User!');

SayGoodbye(console.log);