declare module "some_module" {
  function some_module(string: any): void;
  
  module some_module {
  }
  
  export = some_module;
}